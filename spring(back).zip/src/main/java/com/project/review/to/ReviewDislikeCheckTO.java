package com.project.review.to;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReviewDislikeCheckTO {
	private int dislike_users_seq;
	private int dislike_board_seq;
}
