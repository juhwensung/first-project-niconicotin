package com.project.review.to;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReviewLikeCheckTO {
	private int like_users_seq;
	private int like_board_seq;
}
