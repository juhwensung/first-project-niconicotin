package com.project.Project_Cigar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectCigarApplicationTests {

	@Test
	void contextLoads() {
	}

}
